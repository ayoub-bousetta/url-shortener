

To Do B**ch 
- [*] RED,Green,Refactor
- [] 'Create Nav for profile and urls in index if user is Auth'
- [] 'Create One big component in vue and include it any time we need it'
- [] 'Axios will be the request handler in this'

## Idea
Url Shortner for fun, Trying Some TDD In Action Php side.



## License

This is an open-sourced Code, based on laravel/Vue and some hand written Css.
