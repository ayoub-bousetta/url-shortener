<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app">
        
            
       
      

        <main class="content-warpper-login">
                <?php echo $__env->yieldContent('content'); ?>
            <section class="left-section">

                <div class="bottom">

                        <a class="btn btn-link" href="<?php echo e(route('index')); ?>">
                                <span class="arrow__zoom">⤺</span> <?php echo e(__('Go home')); ?> 
                            </a>

                   
                        <?php if(Route::has('password.request') && Route::current()->getName() != "password.request"): ?>
                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('Forgot Your Password?')); ?> <span class="arrow__zoom">➔</span>
                        </a>
                        <?php endif; ?>


                 

                        

                </div>

                    
            </section>
          
            <section class="right-section">
                <?php if(Route::current()->getName() == "password.request"): ?>
                <span><?php echo e(__('Reset')); ?></span>
                <?php else: ?>
                <span><?php echo e(ucfirst(Route::current()->getName())); ?></span>
                <?php endif; ?>
               
                  
                   
                    
            </section>
       
       
         
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\Users\AuB\Desktop\Learning_2019\ShortnerUrl\url_shortener\resources\views/layouts/login.blade.php ENDPATH**/ ?>