<?php $__env->startSection('content'); ?>

<div class="our-head">
    
    <h1>Shrink That url</h1>
    <div class="our-head_list_info">
      
            <p>Small things are always great! i guess...</p>

</div>
</div>
    
<span class="head-bg">HTTPS</span>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('form-input'); ?>

    


<form-index></form-index>

<?php $__env->stopSection(); ?>
<?php if(auth()->guard()->check()): ?>
<?php $__env->startSection('vue-component'); ?>


<div class="all_url_profile">

    <div class="urls">

        <urls-data action='<?php echo e(route('index')); ?>' url=<?php echo e(URL::to('/')); ?>   :authid='<?php echo json_encode(Auth::user()); ?>'></urls-data>

    </div>
<div class="profile">


    <profile-data :authid='<?php echo json_encode(Auth::user()); ?>'></profile-data>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php endif; ?>


<?php $__env->startSection('errors'); ?>
 <errors></errors>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AuB\Desktop\Learning_2019\ShortnerUrl\url_shortener\resources\views/urls/index.blade.php ENDPATH**/ ?>